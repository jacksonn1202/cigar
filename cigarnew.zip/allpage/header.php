<div class="top__header pt-30 pb-30">
        <div class="container">
            <div class="top__wrapper">
                <a href="index.php" >
                    <img src="assets/images/logo/logo-new.png" class="mo" alt="logo__image">
                </a>
                <!-- <div class="search__wrp">
                    <input placeholder="Search for" aria-label="Search">
                    <button><i class="fa-solid fa-search"></i></button>
                </div> -->
                <div class="account__wrap">
                    <div class="account d-flex align-items-center">
                        <div class="user__icon">
                            <a href="#0">
                                <i class="fa-regular fa-user"></i>
                            </a>
                        </div>
                        <a href="#0" class="acc__cont">
                            <span>
                                My Account
                            </span>
                        </a>
                    </div>
                    <div class="cart d-flex align-items-center">
                        <span class="cart__icon">
                            <i class="fa-regular fa-cart-shopping"></i>
                        </span>
                        <a href="#0" class="c__one">
                            <span>
                                $45.50
                            </span>
                        </a>
                        <span class="one">
                            3
                        </span>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<header class="header-section">
        <div class="container">
            <div class="header-wrapper">
                <div class="header-bar d-lg-none">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <ul class="main-menu">
                    <li>
                        <a href="index.php">Home </a>
                       
                    </li>
                    <li>
                        <a href="javascript:void(0)">About Us</a>
                    </li>
                    <li>
                        <a href="#0">Cigar <i class="fa-regular fa-angle-down"></i></a>
                        <ul class="sub-menu">
                            <li class="subtwohober">
                                <a href="javascript:void(0)">
                                Premium Cigars
                                </a>
                            </li>
                            <li class="subtwohober">
                                <a href="javascript:void(0)">
                                Cigar cutters
                                </a>
                            </li>
                            <li class="subtwohober">
                                <a href="javascript:void(0)">
                                Humidors and cases
                                </a>
                            </li>
                           
                        </ul>
                    </li>
                    <li>
                        <a href="#0">Pipe Tobacco <i class="fa-regular fa-angle-down"></i></a>
                        <ul class="sub-menu">
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Tobacco Pipes</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Pipe Tobacco</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Accessories</a>
                            </li>
                          
                        </ul>
                    </li>
                    <li>
                        <a href="#0">Hookah<i class="fa-regular fa-angle-down"></i></a>
                        <ul class="sub-menu">
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Hookah Sets</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Hookah Tobacco</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Hookah Accessories</a>
                            </li>
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)">Zippo</a>
                    </li>

                    <li>
                        <a href="#0">420<i class="fa-regular fa-angle-down"></i></a>
                        <ul class="sub-menu">
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Grinders</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Rolling Papers</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Rolling Trays</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">Torches and Lighters</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">sprays and Incense</a>
                            </li>
                            <li class="subtwohober">
                            <a href="javascript:void(0)">510 cartridge vapes</a>
                            </li>
                          
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:void(0)">Brands</a>
                    </li>


                </ul>
                
            </div>
        </div>
    </header>